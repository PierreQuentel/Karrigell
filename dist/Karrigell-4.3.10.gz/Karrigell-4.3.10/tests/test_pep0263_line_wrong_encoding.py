#
# -*- coding: ascii  -*-

def index():
    return "नई दिल्ली।। बुलावे"